<?php 
include('include.php');

?>
<?php
 
 if(!isset($_SESSION['SW_U_ID'])){
$login = 0;}
if(!isset($_SESSION['SW_USERNAME'])){
$login = 0;}
if(!isset($_SESSION['SW_PASSWORD'])){
$login = 0;}
if(!isset($_SESSION['SW_PREFIX_NAME'])){
$login = 0;}
if(!isset($_SESSION['SW_U_F_NAME'])){
$login = 0;}
if(!isset($_SESSION['SW_U_L_NAME'])){
$login = 0;}
if(!isset($_SESSION['SW_U_DOB'])){
$login = 0;}
if(!isset($_SESSION['SW_U_ACCESS'])){
$login = 0;}
if(!isset($_SESSION['SW_CONTC_NO'])){
$login = 0;}
if(!isset($_SESSION['SW_EMAIL'])){
$login = 0;}
if(!isset($_SESSION['SW_VALID'])){
$login = 0;}

 
?>
